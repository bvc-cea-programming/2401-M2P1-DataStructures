using UnityEngine;

public class DefenseObjectSO : ScriptableObject
{
    
}
